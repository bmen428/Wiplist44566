#!/usr/bin/env bash
# Install dependencies
apt update && apt install -y chromium chromium-driver
# Install Python packages
pip install --upgrade pip
pip install -r requirements.txt
# Run the bot
python main.py
