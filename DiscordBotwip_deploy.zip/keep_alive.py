from flask import Flask
from threading import Thread
import os

# Criar aplicação Flask
app = Flask(__name__)

@app.route('/')
def index():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Discord Bot - Free Fire Wishlist</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                margin: 0;
                padding: 40px;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .container {
                text-align: center;
                background: rgba(255, 255, 255, 0.1);
                padding: 40px;
                border-radius: 20px;
                backdrop-filter: blur(10px);
                box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            }
            h1 {
                margin-bottom: 20px;
                font-size: 2.5em;
            }
            .status {
                display: inline-block;
                background: #4CAF50;
                padding: 10px 20px;
                border-radius: 25px;
                margin: 20px 0;
                font-weight: bold;
            }
            .description {
                font-size: 1.2em;
                margin: 20px 0;
                opacity: 0.9;
            }
            .emoji {
                font-size: 3em;
                margin: 20px 0;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="emoji">🤖</div>
            <h1>Discord Bot Online</h1>
            <div class="status">✅ ATIVO</div>
            <div class="description">
                Bot de Wishlist Free Fire está rodando!<br>
                Use os comandos no Discord para gerenciar sua wishlist.
            </div>
            <div style="margin-top: 30px; opacity: 0.7;">
                <p>Comandos disponíveis:</p>
                <p>/logar • /adicionar • /remover • /status • /ajuda</p>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/health')
def health():
    return {'status': 'healthy', 'bot': 'running'}

@app.route('/status')
def status():
    return {'status': 'online', 'service': 'discord-bot-freefire'}

def run():
    """Executa o servidor Flask"""
    # Usar porta 5000 como especificado
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

def keep_alive():
    """Inicia o servidor em uma thread separada"""
    print("🌐 Iniciando servidor keep-alive...")
    t = Thread(target=run)
    t.daemon = True
    t.start()
    print(f"✅ Servidor keep-alive rodando na porta 5000")

if __name__ == "__main__":
    keep_alive()
    # Manter o script rodando
    import time
    while True:
        time.sleep(60)
