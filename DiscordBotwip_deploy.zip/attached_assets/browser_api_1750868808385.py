#!/usr/bin/env python3
import time
import json
import tempfile
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

class FreefireWishlistBrowser:
    def __init__(self):
        self.driver = None
        self.uid = None
        self.password = None
        self.setup_browser()
    
    def setup_browser(self):
        """Configura o navegador Chrome com todas as opções necessárias"""
        chrome_options = Options()
        chrome_options.add_argument('--headless')  # Executar em modo invisível
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
        
        # Configurar cookies e localStorage
        chrome_options.add_argument('--enable-local-storage')
        chrome_options.add_argument('--enable-cookies')
        
        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            print("✅ Navegador configurado com sucesso")
        except Exception as e:
            print(f"❌ Erro ao configurar navegador: {e}")
            raise
    
    def fazer_login_arquivo(self, arquivo_dat_path):
        """Faz upload do arquivo .dat e extrai as credenciais"""
        try:
            print("🔄 Acessando página de upload...")
            self.driver.get("https://xv.ct.ws/wishlist/upload.php")
            
            # Aguardar a página carregar
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Procurar por input de arquivo
            file_inputs = self.driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
            if not file_inputs:
                file_inputs = self.driver.find_elements(By.NAME, "credFile")
            
            if file_inputs:
                print("📁 Fazendo upload do arquivo...")
                file_inputs[0].send_keys(os.path.abspath(arquivo_dat_path))
                
                # Procurar e clicar no botão de submit
                submit_buttons = self.driver.find_elements(By.CSS_SELECTOR, "input[type='submit'], button[type='submit']")
                if submit_buttons:
                    submit_buttons[0].click()
                
                # Aguardar resposta
                time.sleep(3)
                
                # Extrair credenciais do JavaScript
                page_source = self.driver.page_source
                
                # Buscar por const uid e const password
                import re
                uid_match = re.search(r'const\s+uid\s*=\s*["\']([^"\']+)["\']', page_source)
                password_match = re.search(r'const\s+password\s*=\s*["\']([^"\']+)["\']', page_source)
                
                if uid_match and password_match:
                    self.uid = uid_match.group(1)
                    self.password = password_match.group(1)
                    print(f"✅ Login realizado com sucesso!")
                    print(f"🆔 UID: {self.uid}")
                    return True
                else:
                    print("❌ Não foi possível extrair as credenciais")
                    return False
            else:
                print("❌ Campo de upload não encontrado")
                return False
                
        except Exception as e:
            print(f"❌ Erro no login: {e}")
            return False
    
    def obter_token(self):
        """Obtém um token válido da API usando o navegador"""
        try:
            print("🔄 Obtendo token...")
            self.driver.get("https://xv.ct.ws/wishlist/token.php")
            
            # Aguardar resposta
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            
            # Pegar resposta JSON
            response_text = self.driver.find_element(By.TAG_NAME, "pre").text
            if not response_text:
                response_text = self.driver.page_source
            
            try:
                data = json.loads(response_text)
                if 'token' in data:
                    print(f"✅ Token obtido: {data['token']}")
                    return data['token']
            except:
                print(f"⚠️ Resposta não é JSON, usando como token: {response_text}")
                return response_text.strip()
                
        except Exception as e:
            print(f"❌ Erro ao obter token: {e}")
            return None
    
    def adicionar_item(self, item_id):
        """Adiciona um item à wishlist usando o navegador"""
        if not self.uid or not self.password:
            print("❌ É necessário fazer login primeiro")
            return False
        
        try:
            # Obter token
            token = self.obter_token()
            if not token:
                print("❌ Falha ao obter token")
                return False
            
            # Construir URL com parâmetros
            url = f"https://xv.ct.ws/wishlist/proxy.php?id={item_id}&add=1&uid={self.uid}&password={self.password}&token={token}"
            
            print(f"🔄 Adicionando item {item_id}...")
            self.driver.get(url)
            
            # Aguardar resposta
            time.sleep(2)
            
            # Pegar resposta
            try:
                response_element = self.driver.find_element(By.TAG_NAME, "pre")
                response_text = response_element.text
            except:
                response_text = self.driver.page_source
            
            print(f"📝 Resposta: {response_text}")
            
            try:
                data = json.loads(response_text)
                if 'Status' in data and 'added' in data['Status']:
                    print(f"✅ Item {item_id} adicionado com sucesso!")
                    return True
                elif 'Error' in data:
                    print(f"❌ Erro da API: {data['Error']}")
                    return False
                else:
                    print(f"⚠️ Resposta inesperada: {data}")
                    return False
            except:
                if 'added' in response_text.lower():
                    print(f"✅ Item {item_id} parece ter sido adicionado!")
                    return True
                else:
                    print(f"❌ Falha ao adicionar item")
                    return False
                
        except Exception as e:
            print(f"❌ Erro ao adicionar item: {e}")
            return False
    
    def remover_item(self, item_id):
        """Remove um item da wishlist"""
        if not self.uid or not self.password:
            print("❌ É necessário fazer login primeiro")
            return False
        
        try:
            token = self.obter_token()
            if not token:
                return False
            
            url = f"https://xv.ct.ws/wishlist/proxy.php?id={item_id}&add=0&uid={self.uid}&password={self.password}&token={token}"
            
            print(f"🔄 Removendo item {item_id}...")
            self.driver.get(url)
            time.sleep(2)
            
            try:
                response_element = self.driver.find_element(By.TAG_NAME, "pre")
                response_text = response_element.text
            except:
                response_text = self.driver.page_source
            
            print(f"📝 Resposta: {response_text}")
            
            if 'removed' in response_text.lower() or 'success' in response_text.lower():
                print(f"✅ Item {item_id} removido com sucesso!")
                return True
            else:
                print(f"❌ Falha ao remover item")
                return False
                
        except Exception as e:
            print(f"❌ Erro ao remover item: {e}")
            return False
    
    def verificar_wishlist(self):
        """Verifica os itens na wishlist atual"""
        if not self.uid or not self.password:
            print("❌ É necessário fazer login primeiro")
            return []
        
        try:
            url = f"https://xv.ct.ws/wishlist/list.php?uid={self.uid}&password={self.password}"
            
            print("🔄 Verificando wishlist...")
            self.driver.get(url)
            time.sleep(2)
            
            try:
                response_element = self.driver.find_element(By.TAG_NAME, "pre")
                response_text = response_element.text
            except:
                response_text = self.driver.page_source
            
            print(f"📝 Resposta: {response_text[:500]}...")
            
            try:
                data = json.loads(response_text)
                if 'Wishlist' in data and data['Wishlist']:
                    items = data['Wishlist']
                    print(f"✅ Wishlist encontrada: {len(items)} itens")
                    for item in items:
                        print(f"   • {item.get('Item_ID', 'ID desconhecido')} - {item.get('Item_Name', 'Nome desconhecido')}")
                    return items
                else:
                    print("📭 Wishlist vazia")
                    return []
            except:
                print("❌ Erro ao processar resposta")
                return []
                
        except Exception as e:
            print(f"❌ Erro ao verificar wishlist: {e}")
            return []
    
    def fechar(self):
        """Fecha o navegador"""
        if self.driver:
            self.driver.quit()
            print("🔒 Navegador fechado")

# Teste da implementação
if __name__ == "__main__":
    print("🚀 TESTANDO COM NAVEGADOR REAL")
    print("=" * 40)
    
    browser = FreefireWishlistBrowser()
    
    try:
        # Fazer login
        if browser.fazer_login_arquivo("attached_assets/guest100067.dat"):
            
            # Verificar wishlist atual
            browser.verificar_wishlist()
            
            # Tentar adicionar item
            sucesso = browser.adicionar_item("908033006")
            
            if sucesso:
                print("\n🔄 Verificando wishlist após adição...")
                browser.verificar_wishlist()
        
    finally:
        browser.fechar()
    
    print("=" * 40)