# Discord Bot - Free Fire Wishlist Manager

## Overview

This project is a Discord bot designed to manage Free Fire wishlist data through file uploads and web scraping. The bot provides a bridge between Discord users and a Free Fire wishlist service, allowing users to upload `.dat` files and interact with wishlist data through Discord commands.

## System Architecture

### Core Components
- **Discord Bot**: Main application built with discord.py for user interaction
- **Web Scraping Module**: Selenium-based browser automation for interacting with Free Fire wishlist websites
- **Flask Web Server**: Keep-alive service to maintain bot uptime on hosting platforms
- **File Processing**: Handles `.dat` file uploads and processing for Free Fire account data

### Technology Stack
- **Python 3.11**: Primary programming language
- **discord.py**: Discord bot framework
- **Selenium**: Web automation and scraping
- **Flask**: Lightweight web server for keep-alive functionality
- **Requests**: HTTP client for API interactions
- **WebDriver Manager**: Automatic Chrome driver management

## Key Components

### 1. Main Bot Application (`main.py`)
- Discord bot initialization with slash commands
- User session management through `sessao_por_usuario` dictionary
- Integration with WishlistAPI class for external service communication
- Admin notification system with configurable `ADMIN_CHAT_ID`

### 2. Browser Automation (`browser_api.py`)
- `FreefireWishlistBrowser` class for headless Chrome automation
- Automated login and file upload functionality
- Cookie and session management for persistent connections
- Error handling and retry mechanisms

### 3. Keep-Alive Service (`keep_alive.py`)
- Flask web server providing status endpoint
- Styled HTML interface showing bot status
- Threading support for concurrent bot operation
- Essential for cloud hosting platforms that require HTTP endpoints

### 4. Wishlist API Integration
- `WishlistAPI` class for HTTP-based interactions
- Session management with proper headers and cookies
- File upload handling for `.dat` files
- Browser simulation through user-agent spoofing

## Data Flow

1. **User Interaction**: Users interact with the bot through Discord slash commands
2. **File Processing**: Bot receives `.dat` files from users and processes them
3. **Web Automation**: Selenium browser automates interactions with Free Fire wishlist websites
4. **Data Extraction**: Bot extracts wishlist information and user credentials
5. **Response Generation**: Processed data is formatted and sent back to Discord users
6. **Session Management**: User sessions are maintained for continued interactions

## External Dependencies

### Python Packages
- `discord.py`: Discord API integration
- `selenium`: Web browser automation
- `webdriver-manager`: Automatic Chrome driver management
- `flask`: Web server for keep-alive functionality
- `requests`: HTTP client library
- `python-dotenv`: Environment variable management

### External Services
- **Discord API**: Bot hosting and user interaction
- **Chrome WebDriver**: Browser automation engine
- **Free Fire Wishlist Service**: Target website for data extraction (xv.ct.ws)

### Environment Variables
- `TOKEN`: Discord bot authentication token
- `OWNER_ID`: Discord user ID for bot owner privileges

## Deployment Strategy

### Development Environment
- Replit-based development with `.replit` configuration
- Automatic dependency installation via `pyproject.toml`
- Parallel workflow execution for bot and web server

### Production Considerations
- Headless Chrome browser operation for server environments
- Flask keep-alive server prevents bot disconnection
- Environment variable management for secure token storage
- Docker-ready configuration with proper Chrome dependencies

### Hosting Requirements
- Python 3.11+ runtime environment
- Chrome browser and ChromeDriver availability
- Network access for Discord API and target websites
- Persistent storage for temporary file handling

## Recent Changes

- June 25, 2025: Successfully implemented Chrome browser with real cookie system
- June 25, 2025: Bot now uses exclusively Selenium WebDriver for all operations
- June 25, 2025: Removed all API fallbacks - browser-only approach confirmed working
- June 25, 2025: Item addition tested and working: 908045008 added successfully
- June 25, 2025: Enhanced anti-detection measures for browser automation
- June 25, 2025: Added server restriction - bot only works in authorized guild (1355544025574150344)
- June 25, 2025: Added channel restriction - bot only works in specific channel (1376490266336301076)

## Changelog

- June 25, 2025: Initial setup and bot recreation
- June 25, 2025: Enhanced file processing and error handling

## User Preferences

Preferred communication style: Simple, everyday language.